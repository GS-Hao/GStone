//
//  NetworkTools.swift
//  yikangdaojia-sq
//
//  Created by xianyikang on 2023/9/7.
//

import Foundation
import Alamofire

enum MethodType {
    case GET
    case POST
}

class NetworkTools: NSObject {
    class func requestData(type: MethodType, URLString: String, parameters: [String: String]? = nil, finishedCallback:@escaping (_ result: AnyObject) -> ()) {
        //获取类型
        let method = type == .GET ? HTTPMethod.get :HTTPMethod.post
        
        let headers: HTTPHeaders = [
//            "Authorization": "Basic VXNlcm5hbWU6UGFzc3dvcmQ=",
            "Accept": "application/json",
            "x-wxapp-session" : "",
            "appId" : "IOS335",
            "api-source" : "ios",
            "Authorization" : "Bearer" ,
            "sign" : "b006e7c209e0208879886dbf7fb767e4",
            "app-version" : "1.4.1",
            "timestamp" : "1694068965"
        ]
        
        print("headers = ",headers)
        
        //发送网络请求
        Alamofire.request(URLString, method: method, parameters: parameters, headers: headers).responseJSON { response in
            //获取结果
            guard let result = response.result.value else{
                print(response.result.error)
                return
            }
            //返回结果
            finishedCallback(result as AnyObject)
        }
    }
}
