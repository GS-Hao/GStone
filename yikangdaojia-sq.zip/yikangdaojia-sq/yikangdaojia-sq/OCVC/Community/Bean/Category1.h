//
//  Category.h
//  xiangle
//
//  Created by wei cui on 2020/9/22.
//  Copyright © 2020 wei cui. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Category1 : NSObject
/** 备注 */
@property (assign, nonatomic) NSInteger id;
/** 备注 */
@property (strong, nonatomic) NSString *name;

@end

NS_ASSUME_NONNULL_END
