//
//  Comment.m
//  xiangle
//
//  Created by wei cui on 2020/3/21.
//  Copyright © 2020 wei cui. All rights reserved.
//

#import "Comment.h"

@implementation Comment

@end
