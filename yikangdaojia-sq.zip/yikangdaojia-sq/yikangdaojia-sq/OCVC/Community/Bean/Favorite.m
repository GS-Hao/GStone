//
//  Favorite.m
//  xiangle
//
//  Created by wei cui on 2020/3/28.
//  Copyright © 2020 wei cui. All rights reserved.
//

#import "Favorite.h"

@implementation Favorite

@end
