//
//  Flash.m
//  ios_enterprise
//
//  Created by wei cui on 2020/2/8.
//  Copyright © 2020 wei cui. All rights reserved.
//

#import "Flash.h"

@implementation Flash

@end
