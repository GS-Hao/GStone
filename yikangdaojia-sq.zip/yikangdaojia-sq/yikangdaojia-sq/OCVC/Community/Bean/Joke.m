//
//  Joke.m

#import "Joke.h"

@implementation Joke

@end
