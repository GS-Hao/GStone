//
//  Like.m
//  xiangle
//
//  Created by wei cui on 2020/3/30.
//  Copyright © 2020 wei cui. All rights reserved.
//

#import "Like.h"

@implementation Like

@end
