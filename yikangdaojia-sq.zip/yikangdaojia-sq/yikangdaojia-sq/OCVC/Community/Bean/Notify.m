//
//  GSNotify.m
//  xiangle
//
//  Created by wei cui on 2020/3/31.
//  Copyright © 2020 wei cui. All rights reserved.
//

#import "Notify.h"

@implementation Notify

@end
