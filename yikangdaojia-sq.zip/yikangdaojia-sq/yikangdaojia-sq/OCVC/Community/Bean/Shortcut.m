//
//  Shortcut.m
//  ios_enterprise
//
//  Created by wei cui on 2020/1/9.
//  Copyright © 2020 wei cui. All rights reserved.
//

#import "Shortcut.h"

@implementation Shortcut

@end
