//
//  User.m
//  xiangle
//
//  Created by wei cui on 2020/4/4.
//  Copyright © 2020 wei cui. All rights reserved.
//

#import "User.h"

@implementation User

@end
