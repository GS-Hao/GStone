//
//  TabBarController.h
//  ios_enterprise
//
//  Created by wei cui on 2020/1/7.
//  Copyright © 2020 wei cui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TabBarController : UITabBarController

@end

NS_ASSUME_NONNULL_END
