//
//  HomeArticleController.h
//  php
//
//  Created by wei cui on 2019/12/5.
//  Copyright © 2019 wei cui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeArticleController : UIViewController
/** 备注 */
@property (assign, nonatomic) NSInteger index;
@end

NS_ASSUME_NONNULL_END
