//
//  RecommendController.h
//  xiangle
//
//  Created by wei cui on 2020/9/30.
//  Copyright © 2020 wei cui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RecommendController : UIViewController

@end

NS_ASSUME_NONNULL_END
