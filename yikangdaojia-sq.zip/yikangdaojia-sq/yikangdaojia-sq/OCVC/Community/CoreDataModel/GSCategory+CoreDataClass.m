//
//  GSCategory+CoreDataClass.m
//  xiangle
//
//  Created by xianyikang on 2023/6/26.
//  Copyright © 2023 wei cui. All rights reserved.
//
//

#import "GSCategory+CoreDataClass.h"

@implementation GSCategory

@end
