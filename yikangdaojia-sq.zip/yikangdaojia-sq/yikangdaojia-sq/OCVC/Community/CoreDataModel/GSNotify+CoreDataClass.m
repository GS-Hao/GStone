//
//  GSNotify+CoreDataClass.m
//  xiangle
//
//  Created by xianyikang on 2023/6/21.
//  Copyright © 2023 wei cui. All rights reserved.
//
//

#import "GSNotify+CoreDataClass.h"

@implementation GSNotify

@end
