//
//  GSShortcut+CoreDataClass.m
//  xiangle
//
//  Created by xianyikang on 2023/6/21.
//  Copyright © 2023 wei cui. All rights reserved.
//
//

#import "GSShortcut+CoreDataClass.h"

@implementation GSShortcut

@end
