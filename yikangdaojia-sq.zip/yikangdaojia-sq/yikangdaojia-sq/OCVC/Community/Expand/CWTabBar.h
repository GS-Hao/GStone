//
//  CWTabBar.h
//
//  Created by wei cui on 2019/11/30.
//  Copyright © 2019 wei cui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CWTabBar : UITabBar
/** 备注 */
@property (weak, nonatomic) UIButton *publishButton;
@end

NS_ASSUME_NONNULL_END
