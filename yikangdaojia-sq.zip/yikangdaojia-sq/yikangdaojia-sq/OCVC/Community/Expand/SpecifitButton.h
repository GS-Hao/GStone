//
//  SpecifitButton.h
//  xiangle
//
//  Created by wei cui on 2020/1/9.
//  Copyright © 2020 wei cui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@interface SpecifitButton : UIButton
/** 备注 */
@property (strong, nonatomic) NSDictionary *field;
@end

NS_ASSUME_NONNULL_END
