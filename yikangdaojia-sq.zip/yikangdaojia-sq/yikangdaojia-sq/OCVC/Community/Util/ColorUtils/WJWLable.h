//
//  WJWLable.h
//  wjwcloudhospital
//
//  Created by ykdzswb on 16/6/15.
//  Copyright © 2016年 WJW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WJWLable : NSObject
-(void)lable:(UILabel*)lab frame:(CGRect )frame font:(UIFont *)font textColor:(UIColor *)textcolor text:(NSString *)text ;
@end
