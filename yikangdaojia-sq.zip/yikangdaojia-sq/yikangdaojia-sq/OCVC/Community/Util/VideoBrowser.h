//
//  VideoBrowser.h
//  xiangle
//
//  Created by wei cui on 2020/3/27.
//  Copyright © 2020 wei cui. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface VideoBrowser : NSObject
-(void)playVideo:(NSURL *)url;
@end

NS_ASSUME_NONNULL_END
