//
//  SZAddImage.h
//  addImage
//
//  Created by mac on 14-5-21.
//  Copyright (c) 2014年 shunzi. All rights reserved.
//

/**
 * 使用说明:直接创建此view添加到你需要放置的位置即可.
 * 属性images可以获取到当前选中的所有图片对象.
 */

#import <UIKit/UIKit.h>

@interface SZAddImage : UIView

@end
