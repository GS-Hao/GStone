//
//  AdvertisViewController.swift
//  yikangdaojia-sq
//
//  Created by xianyikang on 2023/9/8.
//

import UIKit

class AdvertisViewController: GSBaseViewController {
    
    lazy var timer = DispatchSource.makeTimerSource(flags: [], queue: DispatchQueue.global())
    
    var seconds = 0

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        view.backgroundColor = .red
        timeCountDown()
    }
    
    func timeCountDown() {
        timer.schedule(deadline: .now(), repeating: .seconds(5))
        timer.setEventHandler(handler: {
            DispatchQueue.main.async {
                if self.seconds <= 0 {
                    self.terminer()
                }
                self.seconds -= 1
            }
        })
        timer.resume()
    }
    
    func terminer() {
        timer.cancel()
        toRootController()
    }
    
    func toRootController() {
        let window = UIApplication.shared.windows.first!
        
        UIView.transition(with: window, duration: 3, options: .transitionCrossDissolve, animations: {
            let old = UIView.areAnimationsEnabled
            UIView.setAnimationsEnabled(false)
            window.rootViewController = GSTabBarVC()
            UIView.setAnimationsEnabled(old)
        }, completion: { _ in
        })
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
