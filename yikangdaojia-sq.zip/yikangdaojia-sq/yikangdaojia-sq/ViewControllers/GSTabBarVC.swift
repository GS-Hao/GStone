//
//  GSTabBarVC.swift
//  yikangdaojia-sq
//
//  Created by xianyikang on 2023/9/8.
//

import UIKit

class GSTabBarVC: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        initTabBar()
    }
    
    func initTabBar() {
        let home = GSNavigationController(rootViewController: HomeVC())
        home.setNavigationBarHidden(true, animated: false)
        home.tabBarItem.title = "首页"
        home.tabBarItem.image = UIImage(named: "shouye")
        home.tabBarItem.selectedImage = UIImage(named: "shouye2")
        
        let shop = GSNavigationController(rootViewController: ShopVC())
        shop.setNavigationBarHidden(true, animated: false)
        shop.tabBarItem.title = "社区"
        shop.tabBarItem.image = UIImage(named: "faxian")
        shop.tabBarItem.selectedImage = UIImage(named: "faxian2")
        
        let cart = GSNavigationController(rootViewController: CartVC())
        cart.tabBarItem.title = "购物车"
        cart.tabBarItem.image = UIImage(named: "pinglun")
        cart.tabBarItem.selectedImage = UIImage(named: "pinglun2")
        
        let mine = GSNavigationController(rootViewController: MineVC())
        mine.tabBarItem.title = "我的"
        mine.tabBarItem.image = UIImage(named: "user")
        mine.tabBarItem.selectedImage = UIImage(named: "user2")
        
        viewControllers = [home, shop, cart, mine]
        
        self.tabBar.backgroundColor = .white
        
//        setTabBarItemAttributes(bgColor: .brown)
    }
    
    func setTabBarItemAttributes(fontName: String = "Courier",
                                     fontSize: CGFloat = 14,
                                     normalColor: UIColor = .gray,
                                     selectedColor: UIColor = .red,
                                     bgColor: UIColor = .white) {
            // tabBarItem 文字大小
            var attributes: [NSAttributedString.Key: Any] = [.font: UIFont(name: fontName, size: fontSize)!]
            
            // tabBarItem 文字默认颜色
            attributes[.foregroundColor] = normalColor
            UITabBarItem.appearance().setTitleTextAttributes(attributes, for: .normal)
            
            // tabBarItem 文字选中颜色
            attributes[.foregroundColor] = selectedColor
            UITabBarItem.appearance().setTitleTextAttributes(attributes, for: .selected)
            
            // tabBar 文字、图片 统一选中高亮色
            tabBar.tintColor = selectedColor
            
            // tabBar 背景色
            tabBar.barTintColor = bgColor
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
