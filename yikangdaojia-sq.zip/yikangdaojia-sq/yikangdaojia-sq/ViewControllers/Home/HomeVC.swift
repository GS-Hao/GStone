//
//  HomeVC.swift
//  yikangdaojia-sq
//
//  Created by xianyikang on 2023/9/8.
//

import UIKit

class HomeVC: GSBaseViewController, UITableViewDelegate, UITableViewDataSource {
    let cellId = "cellId"
    let tableView = UITableView(frame: .zero, style: .plain)
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellId) as! HomeCell
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 202.0
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        createUI()
    }
    
    func createUI() {
        let cellNib = UINib(nibName: "HomeCell", bundle: nil)
        
        let tableView = UITableView(frame: view.bounds)
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.register(cellNib, forCellReuseIdentifier: cellId)
        
        view.addSubview(tableView)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
