//
//  HomeCell.swift
//  yikangdaojia-sq
//
//  Created by xianyikang on 2023/9/8.
//

import UIKit

class HomeCell: UITableViewCell, UICollectionViewDataSource, UICollectionViewDelegate {
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
//        fatalError("init(coder:) has not been implemented")
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        5
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cellId = "cellectionCellId"
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellId, for: indexPath) as! HomeCollectionCell
        return cell
    }
    
    
    private let kCycleCellID = "kCycleCellID"
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    func setup() {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumInteritemSpacing = 0 //列间距
        layout.minimumLineSpacing = 0 //行间距
        
        self.collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)//初始化
        self.collectionView.translatesAutoresizingMaskIntoConstraints = false
        self.collectionView.isPagingEnabled = true //支持手动翻页
        self.collectionView.register(HomeCollectionCell.self, forCellWithReuseIdentifier: kCycleCellID)
//        collectionView.dataSource = self
//        collectionView.delegate = self
//
//
//
//        self.contentView.addSubview(collectionView!)
    }
    

    @IBAction func btnMoreAction(_ sender: Any) {
        
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.layer.borderWidth = 1
        self.layer.masksToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        
        print("123123123")
    }
    
}
