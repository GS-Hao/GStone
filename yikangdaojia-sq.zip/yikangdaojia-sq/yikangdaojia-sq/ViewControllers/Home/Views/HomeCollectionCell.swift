//
//  HomeCollectionCell.swift
//  yikangdaojia-sq
//
//  Created by xianyikang on 2023/9/8.
//

import UIKit

class HomeCollectionCell: UICollectionViewCell {

    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var newPrice: UILabel!
    @IBOutlet weak var oldPrice: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
